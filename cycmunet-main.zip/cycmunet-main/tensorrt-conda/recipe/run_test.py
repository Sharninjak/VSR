from vapoursynth import core

print(core.cycmunet.CycMuNetVersion())
