from .model import CycMuNet
from .model_sep import CycMuNet as CycMuNetSep
from .train import TrainModel
