#pragma once

#include "helper.h"

namespace UDOLayers {

bool registerDCNLayerPlugin();

bool registerPlugins();

}